﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class LoginToRegister : MonoBehaviour
{
    public void Scence2_2()
    {
        SceneManager.LoadScene("6.Register Scene");
    }
}
