﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class RegisterToLogin : MonoBehaviour
{
    public void Scence()
    {
        SceneManager.LoadScene("5.Login Scene");
    }
}
