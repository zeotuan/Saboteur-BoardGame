﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class RegisterToLobby : MonoBehaviour
{
    public void Scence()
    {
        SceneManager.LoadScene("7.Lobby(1)");
    }
}
