﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Card_highlight : MonoBehaviour
{
    public GameObject OnTrigger;

    public void OnTriggerEnter()
    {
        //OnTrigger.transform
    }
}
