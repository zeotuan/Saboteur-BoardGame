﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CardLibrary : MonoBehaviour
{
    private void Update()
    {
        
    }
    /*
    class CardRow
    {
        class CardColumn
        {
         public bool up = false;
         public bool down = false;
         public bool left = false;
         public bool right = false;
         public bool center = false;
        }
        CardColumn cardCol = new CardColumn();

    }
    class CardType
    {
        bool path = false;
        bool functional = false;
    }
    // Start is called before the first frame update
    void Awake()
    {
        CardRow carlist = new CardRow();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    */
}
