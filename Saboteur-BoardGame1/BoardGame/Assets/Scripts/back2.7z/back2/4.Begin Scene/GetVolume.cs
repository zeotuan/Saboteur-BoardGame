﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;

public class GetVolume : MonoBehaviour
{
    // Start is called before the first frame update
    public Slider slider_value;
    public AudioMixer volume_vlaue;
    void Start()
    {
        /*volume_vlaue.updateMode
        slider_value = 
        */
    }
}
