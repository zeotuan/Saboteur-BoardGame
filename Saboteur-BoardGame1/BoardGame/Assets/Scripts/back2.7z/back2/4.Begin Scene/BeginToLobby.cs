﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class BeginToLobby : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene("7.Lobby(1)");
    }
}
