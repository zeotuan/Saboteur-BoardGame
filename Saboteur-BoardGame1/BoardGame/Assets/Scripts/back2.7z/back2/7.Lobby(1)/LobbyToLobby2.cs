﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class LobbyToLobby2 : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene("8.Lobby(2)");
    }
}
