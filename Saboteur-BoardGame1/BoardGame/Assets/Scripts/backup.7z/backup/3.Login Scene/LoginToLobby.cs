﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class LoginToLobby : MonoBehaviour
{
    public void Scence2_1()
    {
        SceneManager.LoadScene("5.Lobby(1)");
    }
}
