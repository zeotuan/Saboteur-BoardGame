﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class RegisterToLogin : MonoBehaviour
{
    public void Scence()
    {
        SceneManager.LoadScene("3.Login Scene");
    }
}
