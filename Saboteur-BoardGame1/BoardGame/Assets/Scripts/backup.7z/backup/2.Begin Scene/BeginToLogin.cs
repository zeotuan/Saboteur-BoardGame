﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class BeginToLogin : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene("3.Login Scene");
    }
}
