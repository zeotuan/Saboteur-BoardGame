﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class BeginToLobby : MonoBehaviour
{
    public void PlayGame()
    {
        SceneManager.LoadScene("5.Lobby(1)");
    }
}
